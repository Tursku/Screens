import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import ScreenListing from './components/ScreenListing';
import ShoppingCart from './components/ShoppingCart';
import PackageList from './components/PackageList';
import ScreenDetails from './components/ScreenDetails';
import api from './Api';

function App() {
  const [cart, setCart] = useState([]);
  const [screens, setScreens] = useState([]);
  const [packages, setPackages] = useState([]);

  const addToCart = (screen) => { // Lisää ostoskoriin
    setCart(prevCart => [...prevCart, screen]);
    setScreens(prevScreens => prevScreens.filter(item => item.id !== screen.id));
  };

  const removeFromCart = (id) => { // Poisto ostoskorista
    const screen = cart.find(item => item.id === id);
    setCart(prevCart => prevCart.filter(item => item.id !== id));
    setScreens(prevScreens => [...prevScreens, screen]);
  };

  const savePackage = () => { // Paketin tallennus
    const newPackage = {
      id: Date.now(),
      items: cart,
      totalPrice: cart.reduce((total, screen) => total + screen.pricePerWeek, 0),
    };
    setPackages(prevPackages => [...prevPackages, newPackage]);
    setScreens(prevScreens => [...prevScreens, ...cart]);
    setCart([]);
  };

  const removePackage = (id) => { // Paketin poisto
    setPackages(prevPackages => prevPackages.filter(pkg => pkg.id !== id));
  };

  useEffect(() => { // Hae kaikki näytöt
    const fetchScreens = async () => {
      try {
        const response = await api.get('/screen-list');
        setScreens(response.data);
      } catch (err) { // Error jos ei toimi
        console.error('Error fetching screens:', err);
      }
    };
    fetchScreens();
  }, []);

  return (
    <Router>
      <div>
        <PackageList packages={packages} removePackage={removePackage} />
        <ShoppingCart cart={cart} removeFromCart={removeFromCart} savePackage={savePackage} />
        <Routes>
          <Route exact path="/" element={<ScreenListing screens={screens} addToCart={addToCart} />} />
          <Route path="/screen/:id" element={<ScreenDetails screens={screens} />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
