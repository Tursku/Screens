// Apikutsu

import axios from 'axios';

const api = axios.create({
  baseURL: 'https://utils.api.outshine.fi/v1'
});

export default api;
