// Tallennetut paketit

import React from 'react';
import './ScreenListing.css';

const PackageList = ({ packages, removePackage }) => {
  return (
    <div className="package-list">
      <h2>Tallennetut paketit</h2>
      {packages.length === 0 ? (
        <p>Ei tallennettuja paketteja</p>
      ) : (
        <ul>
          {packages.map((pkg, index) => ( // Voi vielä lisätä paketi nimeämisen tähän
            <li key={pkg.id} className="package-item">
              <h3>Paketti nro: {index + 1}</h3>
              <ul>
                {pkg.items.map(item => (
                  <li key={item.id}>{item.name} - {item.pricePerWeek}€</li>
                ))}
              </ul>
              <p>Kokonaishinta: {pkg.totalPrice}€</p>
              <button onClick={() => removePackage(pkg.id)}>Poista paketti</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default PackageList;
