// Näytön lisätiedot

import React from 'react';
import { useParams } from 'react-router-dom';

const ScreenDetails = ({ screens }) => {
  const { id } = useParams();
  const screen = screens.find(screen => screen.id === id);

  if (!screen) {
    return <div>error näyttöä ei löydy</div>;
  }

  return (
    <div>
      <h1>{screen.name}</h1>
      <p><strong>Osoite:</strong> {screen.address}, {screen.postalCode} {screen.city}</p>
      <p><strong>Kuvaus:</strong> {screen.description}</p>
      <p><strong>Leveysaste:</strong> {screen.latitude}</p>
      <p><strong>Pituusaste:</strong> {screen.longitude}</p>
      <p><strong>Hinta per viikko:</strong> {screen.pricePerWeek}€</p>
      <p><strong>Resoluutio:</strong> {screen.resolutionX}x{screen.resolutionY}</p>
      <p><strong>Alkuperäinen resoluutio:</strong> {screen.nativeResolutionX}x{screen.nativeResolutionY}</p>
      <p><strong>Koko:</strong> {screen.size}</p>
      <p><strong>Näyttöjen lukumäärä:</strong> {screen.numScreens}</p>
      <p><strong>Aukioloajat:</strong> {screen.openingTimes}</p>
      <img src={screen.imageList[0]?.url} alt='Kuva näytöstä' className="screen-image"/>
    </div>
  );
};

export default ScreenDetails;
