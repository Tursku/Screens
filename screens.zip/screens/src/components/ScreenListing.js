// Näyttölistaus

import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './ScreenListing.css';

const ScreenListing = ({ screens, addToCart }) => {
  const [search, setSearch] = useState('');
  const [sortOrder, setSortOrder] = useState('name');

  const filteredScreens = screens
    .filter(screen => screen.name.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => {
      switch (sortOrder) {
        case 'name':
          return a.name.localeCompare(b.name);
        case 'priceAsc':
          return a.pricePerWeek - b.pricePerWeek;
        case 'priceDesc':
          return b.pricePerWeek - a.pricePerWeek;
        default:
          return 0;
      }
    });

  return (
    <div>
      <h1>Näytöt</h1>
      <input
        type="text"
        placeholder="Hae näyttöä"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />
      <select value={sortOrder} onChange={(e) => setSortOrder(e.target.value)}>
        <option value="name">Nimi</option>
        <option value="priceAsc">Hinta: nouseva</option>
        <option value="priceDesc">Hinta: laskeva</option>
      </select>
      <div className="screen-list">
        {filteredScreens.map(screen => (
          <div key={screen.id} className="screen-item">
            <img src={screen.imageList[0]?.url} alt='Kuva näytöstä' className="screen-image"/>
            <div className="screen-info">
              <h2>{screen.name}</h2>
              <p>Hinta per viikko: {screen.pricePerWeek}€</p>
              <button onClick={() => addToCart(screen)}>Lisää ostoskoriin</button>
              <Link to={`/screen/${screen.id}`}>
                <button>Näytä tiedot</button>
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ScreenListing;
