// Ostoskori

import React from 'react';
import './ShoppingCart.css'

const ShoppingCart = ({ cart, removeFromCart, savePackage }) => {
  const totalPrice = cart.reduce((total, screen) => total + screen.pricePerWeek, 0);

  return (
    <div className="shopping-cart">
      <h2>Ostoskori</h2>
      <ul>
        {cart.map(screen => (
          <li key={screen.id}>
            {screen.name} - {screen.pricePerWeek}€
            <button onClick={() => removeFromCart(screen.id)}>Poista</button>
          </li>
        ))}
      </ul>
      <p>Kokonaishinta: {totalPrice}€</p>
      {cart.length > 0 && (
        <button onClick={savePackage}>Tallenna ostoskori paketiksi</button>
      )}
    </div>
  );
};

export default ShoppingCart;
